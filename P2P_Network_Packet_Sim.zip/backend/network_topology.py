import json, os
NETWORK_NODES = []
NETWORK_LINKS = []
def _generate_topology():
    nodes = []
    links = []
    num_hosts = 15
    num_routers = 5
    num_switches = 8
    width = 860
    left = 40
    for i in range(1, num_routers + 1):
        x = left + int((i - 1) * (width / max(1, num_routers - 1)))
        nodes.append({"id": f"R{i}", "label": f"Router {i}", "type": "router", "x": x, "y": 80})
    for i in range(1, num_switches + 1):
        x = left + int((i - 1) * (width / max(1, num_switches - 1)))
        nodes.append({"id": f"S{i}", "label": f"Switch {i}", "type": "switch", "x": x, "y": 220})
    for i in range(1, num_hosts + 1):
        x = left + int((i - 1) * (width / max(1, num_hosts - 1)))
        nodes.append({"id": f"H{i}", "label": f"Peer {i}", "type": "host", "x": x, "y": 380})
    for si in range(1, num_switches + 1):
        switch_id = f"S{si}"
        r1 = ((si - 1) % num_routers) + 1
        r2 = (si % num_routers) + 1
        links.append({"source": switch_id, "target": f"R{r1}", "weight": 1})
        links.append({"source": switch_id, "target": f"R{r2}", "weight": 1})
    for si in range(1, num_switches):
        links.append({"source": f"S{si}", "target": f"S{si+1}", "weight": 1})
    for hi in range(1, num_hosts + 1):
        host_id = f"H{hi}"
        switch_idx = ((hi - 1) % num_switches) + 1
        links.append({"source": host_id, "target": f"S{switch_idx}", "weight": 1})
    for ri in range(1, num_routers):
        links.append({"source": f"R{ri}", "target": f"R{ri+1}", "weight": 1})
    if num_routers >= 3:
        links.append({"source": "R1", "target": "R3", "weight": 2})
    if num_routers >= 5:
        links.append({"source": "R2", "target": "R5", "weight": 2})
    return nodes, links

NETWORK_NODES, NETWORK_LINKS = _generate_topology()

def save_topology(nodes, links):
    here = os.path.dirname(__file__)
    path = os.path.join(here, "__persist_topo.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"nodes": nodes, "links": links}, f, indent=2)

try:
    here = os.path.dirname(__file__)
    p = os.path.join(here, "__persist_topo.json")
    if os.path.exists(p):
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
            NETWORK_NODES = data.get("nodes", NETWORK_NODES)
            NETWORK_LINKS = data.get("links", NETWORK_LINKS)
except Exception:
    pass
