from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import List, Optional
import os, uuid, math, json, asyncio, uvicorn
from network_topology import NETWORK_NODES, NETWORK_LINKS, save_topology

app = FastAPI(title="P2P Routing Visualizer (Enhanced v3)")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory=os.path.join(os.path.dirname(__file__), "..", "frontend")), name="static")

class RouteRequest(BaseModel):
    source: str
    destination: str
    algorithm: str = "shortest"

def build_adj_list(nodes=None, links=None):
    nodes = nodes if nodes is not None else NETWORK_NODES
    links = links if links is not None else NETWORK_LINKS
    adj = {}
    for link in links:
        s, t, w = link["source"], link["target"], link.get("weight", 1)
        adj.setdefault(s, []).append((t, w))
        adj.setdefault(t, []).append((s, w))
    return adj

from heapq import heappush, heappop
def shortest_path(source: str, destination: str):
    adj = build_adj_list()
    dist = {node["id"]: float("inf") for node in NETWORK_NODES}
    prev = {node["id"]: None for node in NETWORK_NODES}
    dist[source] = 0
    pq = [(0, source)]
    while pq:
        d, u = heappop(pq)
        if u == destination:
            break
        if d > dist[u]:
            continue
        for v, w in adj.get(u, []):
            nd = d + w
            if nd < dist[v]:
                dist[v] = nd
                prev[v] = u
                heappush(pq, (nd, v))
    if dist.get(destination, float("inf")) == float("inf"):
        return [], float("inf")
    path = []
    cur = destination
    while cur is not None:
        path.append(cur)
        cur = prev[cur]
    path.reverse()
    return path, dist[destination]

def bfs_shortest(source: str, destination: str):
    from collections import deque
    adj = build_adj_list()
    prev = {node["id"]: None for node in NETWORK_NODES}
    visited = set()
    q = deque([source])
    visited.add(source)
    while q:
        u = q.popleft()
        if u == destination:
            break
        for v, _ in adj.get(u, []):
            if v not in visited:
                visited.add(v)
                prev[v] = u
                q.append(v)
    if prev.get(destination, None) is None and source != destination:
        return [], float("inf")
    path = []
    cur = destination
    while cur is not None:
        path.append(cur)
        cur = prev[cur]
    path.reverse()
    return path, len(path)-1

def random_walk(source: str, destination: str, max_hops: int = 50):
    import random
    adj = build_adj_list()
    path = [source]
    visited = set([source])
    attempts = 0
    while path[-1] != destination and attempts < max_hops:
        u = path[-1]
        neighbors = [v for v, _ in adj.get(u, []) if v not in visited]
        if not neighbors:
            if len(path) > 1:
                path.pop()
            else:
                break
        else:
            nxt = random.choice(neighbors)
            path.append(nxt)
            visited.add(nxt)
        attempts += 1
    if path and path[-1] == destination:
        return path, len(path)-1
    return [], float("inf")

def link_state(source: str, destination: str):
    # simulate link-state by running Dijkstra on global map
    return shortest_path(source, destination)

def flooding(source: str, destination: str, max_hops: int = 10):
    from collections import deque
    adj = build_adj_list()
    q = deque([(source, 0)])
    visited = {source: None}
    while q:
        u, depth = q.popleft()
        if u == destination:
            break
        if depth >= max_hops:
            continue
        for v, _ in adj.get(u, []):
            if v not in visited:
                visited[v] = u
                q.append((v, depth+1))
    if destination in visited:
        path = []
        cur = destination
        while cur is not None:
            path.append(cur)
            cur = visited[cur]
        path.reverse()
        return path, len(path)-1
    return [], float("inf")

def bgp_simulated(source: str, destination: str):
    # simple BGP-like preference: slight bonus for router-router hops
    adj = build_adj_list()
    typ = {n["id"]: n.get("type", "host") for n in NETWORK_NODES}
    dist = {node["id"]: float("inf") for node in NETWORK_NODES}
    prev = {node["id"]: None for node in NETWORK_NODES}
    dist[source] = 0
    pq = [(0, source)]
    while pq:
        d, u = heappop(pq)
        if u == destination:
            break
        if d > dist[u]:
            continue
        for v, w in adj.get(u, []):
            bonus = 0.0
            if typ.get(u) == "router" and typ.get(v) == "router":
                bonus = -0.2
            nd = d + w + bonus
            if nd < dist[v]:
                dist[v] = nd
                prev[v] = u
                heappush(pq, (nd, v))
    if dist.get(destination, float("inf")) == float("inf"):
        return [], float("inf")
    path = []
    cur = destination
    while cur is not None:
        path.append(cur)
        cur = prev[cur]
    path.reverse()
    return path, dist[destination]

@app.get("/")
async def root():
    f = os.path.join(os.path.dirname(__file__), "..", "frontend", "index.html")
    return FileResponse(f)

@app.get("/topology")
async def get_topology():
    return {"nodes": NETWORK_NODES, "links": NETWORK_LINKS}

@app.post("/route")
async def get_route(req: RouteRequest):
    algo = (req.algorithm or "shortest").lower()
    if algo == "shortest":
        path, cost = shortest_path(req.source, req.destination)
    elif algo == "bfs":
        path, cost = bfs_shortest(req.source, req.destination)
    elif algo == "random":
        path, cost = random_walk(req.source, req.destination)
    elif algo == "linkstate":
        path, cost = link_state(req.source, req.destination)
    elif algo == "flooding":
        path, cost = flooding(req.source, req.destination, max_hops=30)
    elif algo == "bgp":
        path, cost = bgp_simulated(req.source, req.destination)
    else:
        path, cost = shortest_path(req.source, req.destination)

    per_link_weights = []
    if path and len(path) >= 2:
        adj = build_adj_list()
        for i in range(len(path)-1):
            a, b = path[i], path[i+1]
            w = None
            for v, wt in adj.get(a, []):
                if v == b:
                    w = wt; break
            per_link_weights.append({"from": a, "to": b, "weight": w if w is not None else 1})
    return {"path": path, "hops": max(0, len(path)-1), "cost": cost, "link_weights": per_link_weights}

class AddNodeRequest(BaseModel):
    id: str
    label: Optional[str] = None
    type: Optional[str] = "host"
    x: Optional[int] = 100
    y: Optional[int] = 100
    connect_to: Optional[str] = None
    weight: Optional[int] = 1

@app.post("/add_node")
async def add_node(req: AddNodeRequest):
    ids = {n["id"] for n in NETWORK_NODES}
    if req.id in ids:
        raise HTTPException(status_code=400, detail="Node id already exists")
    node = {"id": req.id, "label": req.label or req.id, "type": req.type or "host", "x": req.x or 100, "y": req.y or 100}
    NETWORK_NODES.append(node)
    if req.connect_to:
        NETWORK_LINKS.append({"source": req.id, "target": req.connect_to, "weight": int(req.weight or 1)})
    try:
        save_topology(NETWORK_NODES, NETWORK_LINKS)
    except Exception as e:
        print("Warning: failed to persist topology:", e)
    return {"nodes": NETWORK_NODES, "links": NETWORK_LINKS}

class AddLinkRequest(BaseModel):
    source: str
    target: str
    weight: Optional[int] = 1

@app.post("/add_link")
async def add_link(req: AddLinkRequest):
    ids = {n["id"] for n in NETWORK_NODES}
    if req.source not in ids or req.target not in ids:
        raise HTTPException(status_code=400, detail="Source or target node does not exist")
    if req.source == req.target:
        raise HTTPException(status_code=400, detail="Source and target must be different")
    # check existing
    for l in NETWORK_LINKS:
        if (l["source"] == req.source and l["target"] == req.target) or (l["source"] == req.target and l["target"] == req.source):
            raise HTTPException(status_code=400, detail="Link already exists")
    NETWORK_LINKS.append({"source": req.source, "target": req.target, "weight": int(req.weight or 1)})
    try:
        save_topology(NETWORK_NODES, NETWORK_LINKS)
    except Exception as e:
        print("Warning: failed to persist topology:", e)
    return {"nodes": NETWORK_NODES, "links": NETWORK_LINKS}

@app.delete("/node/{node_id}")
async def delete_node(node_id: str):
    global NETWORK_NODES, NETWORK_LINKS
    ids = {n["id"] for n in NETWORK_NODES}
    if node_id not in ids:
        raise HTTPException(status_code=404, detail="Node not found")
    NETWORK_NODES = [n for n in NETWORK_NODES if n["id"] != node_id]
    NETWORK_LINKS = [l for l in NETWORK_LINKS if l["source"] != node_id and l["target"] != node_id]
    try:
        save_topology(NETWORK_NODES, NETWORK_LINKS)
    except Exception as e:
        print("Warning: failed to persist topology:", e)
    return {"nodes": NETWORK_NODES, "links": NETWORK_LINKS}

@app.delete("/link")
async def delete_link(source: str, target: str):
    global NETWORK_LINKS
    before = len(NETWORK_LINKS)
    NETWORK_LINKS = [l for l in NETWORK_LINKS if not ((l["source"] == source and l["target"] == target) or (l["source"] == target and l["target"] == source))]
    after = len(NETWORK_LINKS)
    if before == after:
        raise HTTPException(status_code=404, detail="Link not found")
    try:
        save_topology(NETWORK_NODES, NETWORK_LINKS)
    except Exception as e:
        print("Warning: failed to persist topology:", e)
    return {"nodes": NETWORK_NODES, "links": NETWORK_LINKS}

@app.post("/transfer")
async def transfer_file(
    source: str = Form(...),
    destination: str = Form(...),
    algorithm: str = Form("shortest"),
    mode: str = Form("router"),
    chunk_size_kb: int = Form(64),
    parallel: int = Form(5),
    file: UploadFile = File(...),
):
    node_ids = {n["id"] for n in NETWORK_NODES}
    if source not in node_ids or destination not in node_ids:
        raise HTTPException(status_code=400, detail="Invalid source or destination id")
    algo = (algorithm or "shortest").lower()
    if algo == "shortest":
        path, cost = shortest_path(source, destination)
    elif algo == "bfs":
        path, cost = bfs_shortest(source, destination)
    elif algo == "random":
        path, cost = random_walk(source, destination)
    elif algo == "linkstate":
        path, cost = link_state(source, destination)
    elif algo == "flooding":
        path, cost = flooding(source, destination, max_hops=30)
    elif algo == "bgp":
        path, cost = bgp_simulated(source, destination)
    else:
        path, cost = shortest_path(source, destination)
    if not path:
        raise HTTPException(status_code=404, detail="No route found between source and destination")
    uploads_dir = os.path.join(os.path.dirname(__file__), "uploads")
    os.makedirs(uploads_dir, exist_ok=True)
    file_id = str(uuid.uuid4())
    original_name = file.filename or "file"
    name_root, ext = os.path.splitext(original_name)
    file_dir = os.path.join(uploads_dir, file_id)
    os.makedirs(file_dir, exist_ok=True)
    content = await file.read()
    size = len(content)
    chunk_size = max(1, int(chunk_size_kb) * 1024)
    chunk_count = math.ceil(size / chunk_size) if size > 0 else 1
    chunks_meta = []
    for i in range(chunk_count):
        start = i * chunk_size
        end = min(start + chunk_size, size)
        chunk_data = content[start:end]
        chunk_name = f"chunk_{i:04d}"
        chunk_path = os.path.join(file_dir, chunk_name)
        with open(chunk_path, "wb") as cf:
            cf.write(chunk_data)
        chunks_meta.append({"index": i, "path": chunk_path, "size": len(chunk_data)})
    meta = {
        "file_id": file_id,
        "original_name": original_name,
        "size": size,
        "chunk_count": chunk_count,
        "chunk_size": chunk_size,
        "mode": mode,
        "path": path,
    }
    with open(os.path.join(file_dir, "meta.json"), "w", encoding="utf-8") as mf:
        json.dump(meta, mf)
    async def send_chunk_along_path(chunk_index: int):
        # base delay for hop; weight affects hop time in frontend too
        base_delay = 0.02
        # compute total delay as sum of link weights along path * base_delay/1
        adj = build_adj_list()
        total = 0.0
        for i in range(len(path)-1):
            a, b = path[i], path[i+1]
            # find weight
            w = 1
            for v, wt in adj.get(a, []):
                if v == b:
                    w = wt; break
            total += w
        # simulate time proportional to total weight (router/peer mode same here)
        await asyncio.sleep(base_delay * total)
        delivered_dir = os.path.join(file_dir, "delivered")
        os.makedirs(delivered_dir, exist_ok=True)
        src_chunk = os.path.join(file_dir, f"chunk_{chunk_index:04d}")
        dst_chunk = os.path.join(delivered_dir, f"chunk_{chunk_index:04d}")
        with open(src_chunk, "rb") as r, open(dst_chunk, "wb") as w:
            w.write(r.read())
    sem = asyncio.Semaphore(max(1, int(parallel)))
    async def worker(ci):
        async with sem:
            await send_chunk_along_path(ci)
    tasks = [asyncio.create_task(worker(i)) for i in range(chunk_count)]
    await asyncio.gather(*tasks)
    reassembled = os.path.join(uploads_dir, f"reassembled_{file_id}{ext}")
    with open(reassembled, "wb") as out:
        for i in range(chunk_count):
            delivered_chunk = os.path.join(file_dir, "delivered", f"chunk_{i:04d}")
            if not os.path.exists(delivered_chunk):
                raise HTTPException(status_code=500, detail=f"Chunk {i} missing after transfer simulation")
            with open(delivered_chunk, "rb") as cf:
                out.write(cf.read())
    return {
        "path": path,
        "hops": max(0, len(path) - 1),
        "file_id": file_id,
        "file_name": original_name,
        "chunk_count": chunk_count,
        "chunk_size": chunk_size,
        "mode": mode,
        "parallel": parallel,
        "cost": cost,
    }

@app.get("/download/{file_id}")
async def download_file(file_id: str):
    uploads_dir = os.path.join(os.path.dirname(__file__), "uploads")
    if os.path.exists(uploads_dir):
        for fname in os.listdir(uploads_dir):
            if fname.startswith(f"reassembled_{file_id}"):
                return FileResponse(os.path.join(uploads_dir, fname), media_type="application/octet-stream", filename=fname)
    file_dir = os.path.join(uploads_dir, file_id)
    if not os.path.exists(file_dir):
        raise HTTPException(status_code=404, detail="File not found")
    meta_path = os.path.join(file_dir, "meta.json")
    if not os.path.exists(meta_path):
        raise HTTPException(status_code=404, detail="File metadata not found")
    with open(meta_path, "r", encoding="utf-8") as mf:
        meta = json.load(mf)
    chunk_count = meta.get("chunk_count", 0)
    _, ext = os.path.splitext(meta.get("original_name", "file"))
    reassembled = os.path.join(uploads_dir, f"reassembled_{file_id}{ext}")
    with open(reassembled, "wb") as out:
        for i in range(chunk_count):
            delivered_chunk = os.path.join(file_dir, "delivered", f"chunk_{i:04d}")
            if not os.path.exists(delivered_chunk):
                raise HTTPException(status_code=500, detail=f"Chunk {i} missing; file incomplete")
            with open(delivered_chunk, "rb") as cf:
                out.write(cf.read())
    return FileResponse(reassembled, media_type="application/octet-stream", filename=meta.get("original_name", file_id))

@app.get("/health")
async def health():
    return {"status":"ok"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
